<?php
/*
Plugin Name: Less PHP Compiler
Plugin URI: http://shoestrap.org/
Description: This plugin adds the less.php class and makes it available to other plugins and themes.
Version: 1.5.1.2
Author: Aristeides Stathopoulos
Author URI: http://wpmu.io
*/

/*
 * This is a simple plugin that loads the Less.PHP class and makes it available to other plugins and themes.
 * When activated this plugin will not do anything.
 * It has no functionality on its own, but can be used as a dependency for other plugins & themes.
 */

// Load the Less class.
// That class in its turn will be calling the Cache class.
require_once( dirname(__FILE__).'/includes/Less.php');